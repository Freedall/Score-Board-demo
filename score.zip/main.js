//home score

let homeScoreOne =document.getElementById("home-score")
let homeScore=0


function increaseHomeScore1(){
let homeScore1 =document.getElementById("home-score-btn1")
homeScore+=1
homeScoreOne.textContent=homeScore
}

function increaseHomeScore2(){
 let homeScore2=document.getElementById("home-score-btn2")
 homeScore+=2
 homeScoreOne.textContent=homeScore
}

function increaseHomeScore3() {
 let homeScore3 = document.getElementById("home-score-btn3")
 homeScore += 3
 homeScoreOne.textContent = homeScore
}

//guest Score

let guestScoreTwo=document.getElementById("guest-score")
let guestScore = 0

function increaseGuestScore1 () {
let guestScorel=document.getElementById("guest-score-btn1")
 guestScore +=1
 guestScoreTwo.textContent=guestScore
}

function increaseGuestScore2 () {
let guestScore2=document.getElementById("guest-score-btn2")
 guestScore +=2
 guestScoreTwo.textContent=guestScore
}

function increaseGuestScore3 () {
let guestScore3=document.getElementById("guest-score-btn3")
 guestScore +=3
 guestScoreTwo.textContent=guestScore
}


